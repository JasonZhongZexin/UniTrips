/**
 * Copyright (c) 2018. [Zexin Zhong]
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *      http://www.apache.org/licenses/LICENSE-2.0
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions an limitations under the License.
 */


package com.sep.UniTrips.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.sep.UniTrips.R;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;
    private Menu menu;
//    private FloatingActionButton mAddEventButton;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    menu.getItem(0).setVisible(true);
                    HomeFragment homeFragment = new HomeFragment();
                    FragmentTransaction homeFragmentTransaction = getSupportFragmentManager().beginTransaction();
                    homeFragmentTransaction.replace(R.id.fragment_container,homeFragment,"HomeFragment");
                    homeFragmentTransaction.commit();
                    return true;
                case R.id.navigation_dashboard:

                    menu.getItem(0).setVisible(false);
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_setting:

                    menu.getItem(0).setVisible(false);
                    SettingFragment settingFragment = new SettingFragment();
                    FragmentTransaction settingFragmentTransaction = getSupportFragmentManager().beginTransaction();
                    settingFragmentTransaction.replace(R.id.fragment_container,settingFragment,"HomeFragment");
                    settingFragmentTransaction.commit();
                    return true;
            }
            return false;
        }
    };
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        this.menu = menu;

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.refresh:
                Toast.makeText(MainActivity.this, "do refresh", Toast.LENGTH_SHORT).show();
                //TODO finish refresh logic here, but please don't delete this toast cause test code will check it's content

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        mAddEventButton = findViewById(R.id.addEventBtn);
//        mAddEventButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(getApplicationContext(), AddEventActivity.class);
//                startActivity(intent);
//            }
//        });
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        if(findViewById(R.id.fragment_container)!=null){
            HomeFragment homeFragment = new HomeFragment();
            FragmentTransaction homeFragmentTransaction = getSupportFragmentManager().beginTransaction();
            homeFragmentTransaction.replace(R.id.fragment_container,homeFragment,"HomeFragment");
            homeFragmentTransaction.commit();

        }
    }

}
